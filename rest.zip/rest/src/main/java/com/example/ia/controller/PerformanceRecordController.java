package com.example.ia.controller;

import com.example.ia.dtos.PerformanceRecord;
import com.example.ia.repository.PerformanceRecordRepository;
import com.example.ia.repository.SalesmanRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/performance")
public class PerformanceRecordController {

    @Autowired
    private SalesmanRepository salesmanRepository;
    @Autowired
    private PerformanceRecordRepository performanceRepository;

    @PostMapping("/create")
    public ResponseEntity<PerformanceRecord> createPerformanceRecord(@RequestBody PerformanceRecord performanceRecord) {
        if (!salesmanRepository.findBySid(performanceRecord.getSid()).isPresent()) { //sid already exists
            return new ResponseEntity<>(HttpStatus.CONFLICT);
        }
        return new ResponseEntity<>(performanceRepository.save(performanceRecord), HttpStatus.OK);
    }

    @GetMapping("/read")
    public ResponseEntity<List<PerformanceRecord>> readAllPerformanceRecords() {
        return new ResponseEntity<>(performanceRepository.findAll(), HttpStatus.OK);
    }

    @GetMapping("/read/{sid}")
    public ResponseEntity<PerformanceRecord> readPerformanceRecordBySid(@PathVariable("sid") String sid) {
        Optional<PerformanceRecord> performanceRecordOptional = performanceRepository.findBySid(sid);
        if (performanceRecordOptional.isPresent()) {
            try {
                return new ResponseEntity<>(performanceRecordOptional.get(), HttpStatus.OK);
            } catch (Exception e) {
                return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @PutMapping("/update/{sid}")
    public ResponseEntity<PerformanceRecord> updatePerformanceRecordBySid
            (@PathVariable("sid") String sid, @RequestBody PerformanceRecord newPerformanceData) {
        Optional<PerformanceRecord> performanceRecordOptional = performanceRepository.findBySid(sid);
        if (performanceRecordOptional.isPresent()) {
            try {
                PerformanceRecord performanceRecord = performanceRecordOptional.get();

                performanceRecord.setTargetValue(newPerformanceData.getTargetValue());
                performanceRecord.setActualValue(newPerformanceData.getActualValue());
                performanceRecord.setYear(newPerformanceData.getYear());
                performanceRecord.setComment(newPerformanceData.getComment());

                return new ResponseEntity<>(performanceRepository.save(performanceRecord), HttpStatus.OK);
            } catch (Exception e) {
                return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @GetMapping("/delete/{sid}")
    public ResponseEntity<HttpStatus> deletePerformanceRecordBySid(@PathVariable("sid") String sid){
        Optional<PerformanceRecord> performanceRecordOptional = performanceRepository.findBySid(sid);
        if(performanceRecordOptional.isPresent()){
            try {
                performanceRepository.deleteBySid(sid);
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }
            catch(Exception e){
                return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

}
