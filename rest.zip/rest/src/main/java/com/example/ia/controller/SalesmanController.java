package com.example.ia.controller;

import com.example.ia.dtos.Salesman;
import com.example.ia.repository.SalesmanRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/salesman")
public class SalesmanController {

    @Autowired
    private SalesmanRepository salesmanRepository;

   // private PerformanceRecordRepository performanceRepository;



    @PostMapping("/create")
    public ResponseEntity<Salesman> createSalesman(@RequestBody Salesman salesman) {
        if(salesmanRepository.findBySid(salesman.getSid()).isPresent()) return new ResponseEntity<>(HttpStatus.CONFLICT); //sid already exists
        return new ResponseEntity<>(salesmanRepository.save(salesman), HttpStatus.CREATED);
    }

    @GetMapping("/read")
    public ResponseEntity<List<Salesman>> readAllSalesman() {
        return new ResponseEntity<>(salesmanRepository.findAll(), HttpStatus.OK);
    }

    @GetMapping("/read/{sid}")
    public ResponseEntity<Salesman> readSalesmanBySid(@PathVariable("sid") String sid){
        Optional<Salesman> salesmanOptional = salesmanRepository.findBySid(sid);
        if(salesmanOptional.isPresent()){
            try {
                return new ResponseEntity<>(salesmanOptional.get(),HttpStatus.OK);
            }
            catch(Exception e){
                return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @PutMapping("update/{sid}")
    public ResponseEntity<Salesman> updateSalesmanBySid(@PathVariable("sid") String sid, @RequestBody Salesman newSalesmanData){
        Optional<Salesman> salesmanOptional = salesmanRepository.findBySid(sid);
        if(salesmanOptional.isPresent()){
            try{
                Salesman salesman = salesmanOptional.get();

                salesman.setFirstName(newSalesmanData.getFirstName());
                salesman.setLastName(newSalesmanData.getLastName());

                return new ResponseEntity<>(salesmanRepository.save(salesman),HttpStatus.OK);
            }
            catch (Exception e){
                return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @GetMapping("/delete/{sid}")
    public ResponseEntity<HttpStatus> deleteSalesmanBySid(@PathVariable("sid") String sid){
        Optional<Salesman> salesmanOptional = salesmanRepository.findBySid(sid);
   //     Optional<PerformanceRecord> performanceRecordOptional = performanceRepository.findBySid(sid);
        if(salesmanOptional.isPresent()){
            try {
                salesmanRepository.deleteBySid(sid);
   //             if(performanceRecordOptional.isPresent()){  // delete
  //                  performanceRepository.deleteBySid(sid);
  //              }
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }
            catch(Exception e){
                return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }
}

