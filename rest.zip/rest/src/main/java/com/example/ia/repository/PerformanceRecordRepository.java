package com.example.ia.repository;

import com.example.ia.dtos.PerformanceRecord;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.Optional;

public interface PerformanceRecordRepository extends MongoRepository<PerformanceRecord, String> {

    Optional<PerformanceRecord> findBySid(String sid);
    void deleteBySid(String sid);
}
