package com.example.ia.dtos;

import com.mongodb.lang.NonNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document("salesman")
public class Salesman {

    @Id
    private String id;
    private String sid;
    private String firstName;
    private String lastName;

    public Salesman(String sid, String firstName, String lastname) {
        this.sid = sid;
        this.firstName = firstName;
        this.lastName = lastname;
    }

    public Salesman(){

    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getSid() {
        return sid;
    }

    public void setSid(String sid) {
        this.sid = sid;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastname) {
        this.lastName = lastname;
    }

    @Override
    public String toString() {
        return "SalesmanDTO{" +
                "id=" + id +
                ", sid=" + sid +
                ", firstName='" + firstName + '\'' +
                ", lastname='" + lastName + '\'' +
                '}';
    }

}
