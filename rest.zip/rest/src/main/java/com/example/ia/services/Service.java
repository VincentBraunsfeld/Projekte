package com.example.ia.services;

@org.springframework.stereotype.Service
public class Service<Model> { // wird gerade noch nicht gebraucht, da sofort auf das repository zugegriffen wird

 /*   @Autowired
    private Repository<Model> repository;

    public List<Model> readAllSalesman() {
        List<Model> salesmanList = repository.findAll();
        return salesmanList;
    }

    public Model createSalesman(Model model) {
        return repository.save(model);
    }

    public Optional<Model> readSalesman(String sid) {
        return repository.findById(sid);
    }

    public void updateSalesman(String sid, Model model) {
        repository.save(model);
    }

    public void deleteSalesman(String sid){
        repository.deleteById(sid);
    }*/
}
