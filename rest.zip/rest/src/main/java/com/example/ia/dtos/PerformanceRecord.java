package com.example.ia.dtos;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document("PerformanceRecords")
public class PerformanceRecord {

    @Id
    private String id;
    private String sid;
    private int targetValue;
    private int actualValue;
    private int year;
    private String comment;

    public PerformanceRecord(String sid, int targetValue, int actualValue, int year, String comment) {
        this.sid = sid;
        this.targetValue = targetValue;
        this.actualValue = actualValue;
        this.year = year;
        this.comment = comment;
    }


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getSid() {
        return sid;
    }

    public void setSid(String sid) {
        this.sid = sid;
    }

    public int getTargetValue() {
        return targetValue;
    }

    public void setTargetValue(int targetValue) {
        this.targetValue = targetValue;
    }

    public int getActualValue() {
        return actualValue;
    }

    public void setActualValue(int actualValue) {
        this.actualValue = actualValue;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }




    @Override
    public String toString() {
        return "PerformanceDTO{" +
                "id=" + id +
                ", sid=" + sid +
                ", targetValue=" + targetValue +
                ", actualValue=" + actualValue +
                ", year=" + year +
                ", comment='" + comment + '\'' +
                '}';
    }


}
