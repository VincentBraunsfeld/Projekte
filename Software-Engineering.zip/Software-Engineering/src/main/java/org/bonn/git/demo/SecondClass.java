package org.bonn.git.demo;

// Franziskas new comment on the class
public class SecondClass {
}
