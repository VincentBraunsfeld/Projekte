package org.hbrs.se2.project.hellocar.dtos.account;

public interface CompanyDTO extends JobPortalUserDTO {

    public String getCompanyName();

    public String getWebSite();

}

