package org.hbrs.se2.project.hellocar.services.search;

public interface JobApplicationSearch {

    void setApplicantFirstName(String applicantFirstName);
    void setApplicantLastName(String applicantLastName);
    void setJobTitle(String jobTitle);
}
