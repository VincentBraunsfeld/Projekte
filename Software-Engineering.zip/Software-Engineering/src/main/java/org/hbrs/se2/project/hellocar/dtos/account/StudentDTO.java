package org.hbrs.se2.project.hellocar.dtos.account;

public interface StudentDTO extends JobPortalUserDTO {
    public String getStudyCourse();

    public String getSpecialization();

    public Integer getSemester();

    public String getDegree();


}

