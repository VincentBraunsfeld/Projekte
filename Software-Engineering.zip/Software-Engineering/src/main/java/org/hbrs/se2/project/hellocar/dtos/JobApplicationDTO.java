package org.hbrs.se2.project.hellocar.dtos;

public interface JobApplicationDTO {

    int getJobApplicationId();

    public String getText();

    public byte[] getResume();

    int getId();

    int getJobAdvertisementId();
}
