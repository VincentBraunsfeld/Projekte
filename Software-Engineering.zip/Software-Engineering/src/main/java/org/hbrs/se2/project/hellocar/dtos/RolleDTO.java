package org.hbrs.se2.project.hellocar.dtos;

public interface RolleDTO {
        public String getBezeichhnung();

}
