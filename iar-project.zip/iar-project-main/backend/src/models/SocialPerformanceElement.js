class SocialPerformanceElement{
    constructor(description, targetValue, actualValue, bonus, comment) {
        this.description = description;
        this.targetValue = targetValue;
        this.actualValue = actualValue;
        this.comment = comment;
    }
}