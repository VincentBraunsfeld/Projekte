/**
 * this model specifies the format to exchange userdata with the frontend and store it in mongoDB
 * @param {string} name
 * @param {number} quantity
 * */
class Position{
    constructor(name, quantity) {
        this.name = name;
        this.quantity = quantity;
    }
}

module.exports = Position;