/**
 * this model specifies the format to exchange userdata with the frontend and store it in mongoDB
 * @param {string} name
 * @param {string} rating
 * */
class Customer {
    constructor(name, rating) {
        this.name = name;
        this.rating = rating;
    }
}

module.exports = Customer