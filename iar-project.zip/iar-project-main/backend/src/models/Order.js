/**
 * this model specifies the format to exchange userdata with the frontend and store it in mongoDB
 * @param {number} sid
 * @param {year} number
 * @param {customer} Customer
 * @param {positions[]} Position
 * */
class Order{
    constructor(sid, year, customer, positions) {
        this.sid = sid;
        this.year = year;
        this.customer = customer;
        this.positions = positions;
    }
}

module.exports = Order;
