/**
 * this model specifies the format to exchange userdata with the frontend and store it in mongoDB
 * @param {number} sid
 * @param {number} employeeId
 * @param {string} firstname
 * @param {string} lastname
 * @param {string} department
 * */


class Salesman{
    constructor(sid, employeeId, firstName, lastName, department) {
        this.sid = sid;                //code in HRM
        this.employeeId = employeeId;  //not visible in OrangeHRM, is used to store the bonus in HRM
        this.firstName = firstName;
        this.lastName = lastName;
        this.department = department;
    }
}

module.exports = Salesman;