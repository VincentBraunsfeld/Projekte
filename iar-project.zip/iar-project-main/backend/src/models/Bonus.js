class Bonus{
    constructor(sid, year, remarks, value, confirmedByCeo =false, confirmedByHR=false) {
        this.sid = sid;
        this.year = year;
        this.value = value;
        this.remarks = remarks;
        this.confirmedByCeo = confirmedByCeo;
        this.confirmedByHR = confirmedByHR;
    }
}

module.exports = Bonus;