class SocialPerformance {
    constructor(sid, year, socialPerformanceElements, bonus) {
        this.sid = sid;
        this.year = year;
        this.socialPerformanceElements = socialPerformanceElements;
        this.bonus = bonus;

    }
}

module.exports = SocialPerformance;