const socialPerformanceService = require('../services/socialPerformance-service');
const SocialPerformance = require('../models/SocialPerformance');

/**
 * endpoint, which creates a socialPerformance
 * @param req express request
 * @param res express response
 * @return {Promise<void>}
 */


exports.create = async function (req, res) {
    const db = req.app.get('db');
    const sid = req.body.sid;
    const year = req.body.year;
    const exist = await socialPerformanceService.getBySidAndYear(db, sid, year);
    if(exist.length !== 0) {
        res.status(400).send('already exist');
    }
    else {
        await socialPerformanceService.create(db, req.body);
        res.status(201).send('created');
    }
}

/**
 * endpoint, which returns all socialPerformances
 * @param req express request
 * @param res express response
 * @return {Promise<void>}
 */


exports.getAll = async function (req, res) {
    const db = req.app.get('db');
    res.json(await socialPerformanceService.getAll(db));
}

/**
 * endpoint, which returns all socialPerformances with a certain id
 * @param req express request
 * @param res express response
 * @return {Promise<void>}
 */


exports.getBySid =async function (req, res) {
    const db = req.app.get('db');
    const sid = parseInt(req.params.sid);
    const social = await socialPerformanceService.getBySid(db, sid);
    console.log(social);
    if (social.length === 0) {
        res.status(404).send('not found');
    } else {
        res.json(social);
    }
}

/**
 * endpoint, which returns a single socialPerformance
 * @param req express request
 * @param res express response
 * @return {Promise<void>}
 */


exports.getBySidAndYear =async function (req, res) {
    const db = req.app.get('db');
    const sid = parseInt(req.params.sid);
    const year = parseInt(req.params.year);
    const social = await socialPerformanceService.getBySidAndYear(db, sid, year);

    if (social.length === 0) {
        res.status(404).send();
    } else {
        res.json(social);
    }

}

/**
 * endpoint, which updates a socialPerformance
 * @param req express request
 * @param res express response
 * @return {Promise<void>}
 */



exports.update = async function (req, res) {
    const db = req.app.get('db');
    const sid = parseInt(req.params.sid);
    const year = parseInt(req.params.year);
    const exist = await socialPerformanceService.getBySidAndYear(db, sid, year);

    if(exist.length === 0) {
        res.status(404).send('nothing to update');
    }
    else {
        (await socialPerformanceService.update(db, sid, year, req.body));
        res.status(201).send("updated");
    }

}

/**
 * endpoint, which deletes all socialPerformances with a certain id
 * @param req express request
 * @param res express response
 * @return {Promise<void>}
 */


exports.deleteBySid = async function(req, res){
    const db = req.app.get('db');
    const sid = parseInt(req.params.sid);
    const exist = await socialPerformanceService.getBySid(db, sid);

    if(exist.length === 0) {
        res.status(404).send('nothing to delete');
    }
    else{
        await socialPerformanceService.deleteBYSid(db, sid);
        res.status(203).send("deleted");
    }
}

/**
 * endpoint, which deletes a single socialPerformances
 * @param req express request
 * @param res express response
 * @return {Promise<void>}
 */


exports.deleteBySidAndYear = async function(req, res){
    const db = req.app.get('db');
    const sid = parseInt(req.params.sid);
    const year = parseInt(req.params.year);
    const exist = await socialPerformanceService.getBySidAndYear(db, sid, year);

    if(exist.length === 0) {
        res.status(404).send('nothing to delete');
    }
    else{
        await socialPerformanceService.deleteBySidAndYear(db, sid, year);
        res.status(203).send("deleted");
    }
}
