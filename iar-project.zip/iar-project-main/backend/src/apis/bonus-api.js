const bonusService = require('../services/bonus-service');
const salesmanService = require("../services/salesman-service");
const Bonus = require('../models/Bonus');


/**
 * endpoint, which creates a bonus
 * @param req express request
 * @param res express response
 * @return {Promise<void>}
 */


exports.create = async function (req, res) {
    const db = req.app.get('db');
    const { sid, year, value, remarks, confirmedByCeo, confirmedByHR } = req.body;
    const exist = await bonusService.getBySidAndYear(db, sid, year);
    if (exist.length !== 0) {
        res.status(400).send('already exist');
    } else {
        const bonus = new Bonus(sid, year, remarks, value, confirmedByCeo, confirmedByHR);
        await bonusService.create(db, bonus);
        res.status(201).send(bonus);
    }
}

/**
 * endpoint, which returns all bonuses
 * @param req express request
 * @param res express response
 * @return {Promise<void>}
 */


exports.getAll = async function (req, res) {
    const db = req.app.get('db');
    res.json(await bonusService.getAll(db));
}

/**
 * endpoint, which returns all bonuses with a certain id
 * @param req express request
 * @param res express response
 * @return {Promise<void>}
 */


exports.getBySid = async function (req, res) {
    const db = req.app.get('db');
    const sid = parseInt(req.params.sid);
    const bonus = await bonusService.getBySid(db, sid);

    if (bonus.length === 0) {
        res.status(404).send('not found');
    } else {
        res.json(bonus);
    }
}

/**
 * endpoint, which returns a single bonus
 * @param req express request
 * @param res express response
 * @return {Promise<void>}
 */


exports.getBySidAndYear = async function (req, res) {
    const db = req.app.get('db');
    const sid = parseInt(req.params.sid);
    const year = parseInt(req.params.year);
    const bonus = await bonusService.getBySidAndYear(db, sid, year);

    if (bonus.length === 0) {
        res.status(404).send();
    } else {
        res.json(bonus);
    }

}

/**
 * endpoint, which updates a single bonus
 * @param req express request
 * @param res express response
 * @return {Promise<void>}
 */


exports.update = async function (req, res) {
    const db = req.app.get('db');
    const sid = parseInt(req.params.sid);
    const year = parseInt(req.params.year);
    const exist = await bonusService.getBySidAndYear(db, sid, year);

    if (exist.length === 0) {
        res.status(404).send('nothing to update');
    } else {
        (await bonusService.update(db, sid, year, req.body));
        res.status(201).send('updated', exist);
    }

}


/**
 * endpoint, which deletes all bonuses with a certain id
 * @param req express request
 * @param res express response
 * @return {Promise<void>}
 */


exports.deleteBySid = async function (req, res) {
    const db = req.app.get('db');
    const sid = parseInt(req.params.sid);
    const exist = await bonusService.getBySid(db, sid);

    if (exist.length === 0) {
        res.status(404).send('nothing to delete');
    } else {
        await bonusService.deleteBySid(db, sid);
        res.status(203).send("deleted");
    }
}

/**
 * endpoint, which deletes a single bonus
 * @param req express request
 * @param res express response
 * @return {Promise<void>}
 */


exports.deleteBySidAndYear = async function (req, res) {
    const db = req.app.get('db');
    const sid = parseInt(req.params.sid);
    const year = parseInt(req.params.year);
    const exist = await bonusService.getBySidAndYear(db, sid, year);

    if (exist.length === 0) {
        res.status(404).send('nothing to delete');
    } else {
        await bonusService.deleteBySidAndYear(db, sid, year);
        res.status(203).send("deleted");
    }
}
//to do: error handling, map sid to employeeId to store the data in Orange HRM
exports.confirmBonus = async function (req, res) {
    const {sid, year, value} = req.body;
    const {employeeId} = await salesmanService.getBySid(parseInt(sid));
    await bonusService.confirmBonus(employeeId, year, value);
    res.status(201).json({message: 'worked'});
}