const salesmanService = require('../services/salesman-service');


/**
 * endpoint, return all salesman
 * @param req express request
 * @param res express response
 * @return {Promise<void>}
 */
exports.getAll = async function(req, res){
    res.json(await salesmanService.getAll());
}

/**
 * endpoint, returns a certain salesman by id
 * @param req express request
 * @param res express response
 * @return {Promise<void>}
 */
exports.getBySid = async function(req, res){
    const sid = parseInt(req.params.sid);
    const salesman = await salesmanService.getBySid(sid);
    if(salesman.length === 0) {
        res.status(404).json({message: 'no orders found'});
    }
    else{
        res.json(salesman);
    }
}
