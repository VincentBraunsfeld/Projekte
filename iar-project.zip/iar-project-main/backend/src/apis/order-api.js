const orderService = require('../services/order-service');
const Order = require('../models/Order');

/**
 * endpoint, return all orders
 * @param req express request
 * @param res express response
 * @return {Promise<void>}
 */
exports.getAll = async function(req, res){
    res.json(await orderService.getAll());
}
/**
 * endpoint, return all orders with a certain sid and year
 * @param req express request
 * @param res express response
 * @return {Promise<void>}
 */
exports.getBySidAndYear = async function(req, res){
    const sid = parseInt(req.params.sid);
    const year = parseInt(req.params.year);
    const order = await orderService.getBySidAndYear(sid, year);
    console.log(order);
    if(order.length === 0) {
        res.status(404).json({message: 'no orders found'});
    }
    else{
        res.json(order);
    }
}

exports.getBySid = async function(req, res){
    const sid = parseInt(req.params.sid);
    const orders = await orderService.getBySid(sid);
    if(orders.length === 0) {
        res.status(404).json({message: 'no orders found'});
    }
    else{
        res.json(orders);
    }
}

