const express = require('express');
const router = express.Router();
const {checkAuthorization} = require('../middlewares/auth-middleware');

/*
    In this file is the routing for the REST-endpoints under /api managed
 */

const authApi = require('../apis/auth-api'); //api-endpoints are loaded from separate files
router.post('/login', authApi.login); //the function decides which request type should be accepted
router.delete('/login', checkAuthorization(),authApi.logout); //middlewares can be defined in parameters
router.get('/login', authApi.isLoggedIn); //the function, which handles requests is specified as the last parameter

const userApi = require('../apis/user-api');
router.get('/user', checkAuthorization(), userApi.getSelf);

module.exports = router;

const salesmanApi = require('../apis/salesman-api');
router.get('/salesman',  salesmanApi.getAll);
router.get('/salesman/:sid', salesmanApi.getBySid);

const orderApi = require('../apis/order-api');
router.get('/order',  orderApi.getAll);
router.get('/order/:sid/:year', orderApi.getBySidAndYear);
router.get('/order/:sid', orderApi.getBySid);

const socialPerformanceApi = require('../apis/socialPerformance-api');
router.post('/socialPerformance', socialPerformanceApi.create);
router.get('/socialPerformance', socialPerformanceApi.getAll);
router.get('/socialPerformance/:sid', socialPerformanceApi.getBySid);
router.get('/socialPerformance/:sid/:year', socialPerformanceApi.getBySidAndYear);
router.put('/socialPerformance/:sid/:year', socialPerformanceApi.update);
router.delete('/socialPerformance/:sid', socialPerformanceApi.deleteBySid);
router.delete('/socialPerformance/:sid/:year', socialPerformanceApi.deleteBySidAndYear);

const bonusApi = require('../apis/bonus-api');
router.post('/bonus', bonusApi.create);
router.post('/bonus/confirm', bonusApi.confirmBonus);
router.get('/bonus', bonusApi.getAll);
router.get('/bonus/:sid', bonusApi.getBySid);
router.get('/bonus/:sid/:year', bonusApi.getBySidAndYear);
router.put('/bonus/:sid/:year', bonusApi.update);
router.delete('/bonus/:sid', bonusApi.deleteBySid);
router.delete('/bonus/:sid/:year', bonusApi.deleteBySidAndYear);



