const axios = require('axios');
const qs = require('querystring');


const baseUrl = 'https://sepp-hrm.inf.h-brs.de/symfony/web/index.php';

const body = qs.stringify({
    client_id: 'api_oauth_id',
    client_secret: 'oauth_secret',
    grant_type: 'password',
    username: 'braunsfeld',
    password: '*Safb02da42Demo$'
});
const config = {
    headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Accept': 'application/json',
    }
};

async function authenticate() {
    try {
        const res = await axios.post(`${baseUrl}/oauth/issueToken`, body, config);
        //access_token
        return res.data['access_token'];
    } catch (e) {
        throw Error(res.data.error);
    }
}

module.exports = {baseUrl, authenticate};


