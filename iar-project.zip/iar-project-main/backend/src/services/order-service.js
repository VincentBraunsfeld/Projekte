const axios = require('axios');
const Customer = require('../models/Customer');
const Position = require('../models/Position');
const Order = require('../models/Order')
const baseUrl = 'https://sepp-crm.inf.h-brs.de/opencrx-rest-CRX';
const credentials = {
    username: 'guest',
    password: 'guest',
};

const config = {
    headers: {
        'Accept': 'application/json'
    },
    auth: credentials,
};


async function getAll() {
    const orders = [];

    const res = await axios.get(`${baseUrl}/org.opencrx.kernel.contract1/provider/CRX/segment/Standard/salesOrder`, config);
    const salesOrders = res.data.objects;
    for (const salesOrder of salesOrders) {
        const sid = await getSalesmanId(salesOrder); //delivers the government id, which is equal to the salesman id(code) in orangeHRM
        const year = await getSalesOrderYear(salesOrder); // delivers the salesOrder year
        const customer = await getCustomer(salesOrder); //delivers a customer object with the attributes name and rating
        const positions = await getPosition(salesOrder); //delivers a list of position objects with the attributes name and quantity

        if (!sid) continue;
        if (positions.length > 0) {

            orders.push(new Order(sid, year, customer, positions));
        }
    }
    console.log(orders);
    return orders;
}

async function getSalesmanId(salesOrder) {
    const id = salesOrder['salesRep']['@href'].split('/').at(-1);
    const res = await axios.get(`${baseUrl}/org.opencrx.kernel.account1/provider/CRX/segment/Standard/account/${id}`, config);
    return res.data['governmentId'];
}

async function getSalesOrderYear(salesOrder) {
    return parseInt(salesOrder.createdAt.split('-')[0]);
}

async function getCustomer(salesOrder) {
    const id = salesOrder['customer']['@href'].split('/').at(-1);
    const res = await axios.get(`${baseUrl}/org.opencrx.kernel.account1/provider/CRX/segment/Standard/account/${id}`, config);

    //map ratings
    let rating = null;
    switch (res.data.accountRating) {
        case 1:
            rating = 'excellent';
            break;
        case 2:
            rating = 'very good';
            break;
        case 3:
            rating = 'good';
    }

    return new Customer(res.data.fullName, rating);
}

async function getPosition(salesOrder) {
    const positions = [];
    const id = salesOrder['@href'].split('/').at(-1); //salesOrder id
    const res = await
        axios.get(`${baseUrl}//org.opencrx.kernel.contract1/provider/CRX/segment/Standard/salesOrder/${id}/position`, config);
    const objects = res.data.objects;
    if (objects) {
        for (const object of objects) {
            const product_id = object['product']['@href'].split('/').at(-1);
            const res = await
                axios.get(`${baseUrl}/org.opencrx.kernel.product1/provider/CRX/segment/Standard/product/${product_id}`, config);
            const name = res.data.name;
            const quantity = parseInt(object.quantity);
            positions.push(new Position(name, quantity));

        }
    }
    return positions;
}

async function getBySidAndYear(sid, year) {
    return ((await getAll()).filter(order => order.sid === sid && order.year === year));

}

async function getBySid(sid) {
    return ((await getAll()).filter(order => order.sid === sid));

}

getAll();


module.exports = {getAll, getBySidAndYear, getBySid};



