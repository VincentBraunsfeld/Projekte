const axios = require('axios');
const qs = require('querystring');
const Salesman = require('../models/Salesman');
const { baseUrl, authenticate } = require('../authentication/orangeHRM');
const {login} = require("../apis/auth-api");



async function getAll() {
    const salesman = [];
    const res = await axios.get(`${baseUrl}/api/v1/employee/search`,
        {headers: {Authorization: `Bearer ${await authenticate()}`}}
    );
    const objects = res.data.data.filter((e) => e.unit === 'Sales');

    for (object of objects) {
        const {code, employeeId, firstName, lastName, unit} = object;
        salesman.push(new Salesman(parseInt(code), parseInt(employeeId), firstName, lastName, unit));
    }
    return salesman;
}

async function getBySid(sid) {
    return (await getAll()).filter(salesman => salesman.sid === sid)[0];
}
getAll();
module.exports = {getAll, getBySid};




