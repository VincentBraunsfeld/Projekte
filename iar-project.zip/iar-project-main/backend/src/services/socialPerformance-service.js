exports.getAll = async function(db){
    return (await db.collection('socialPerformance').find().toArray());
}

exports.getBySid = async function (db, sid) {
    return (await db.collection('socialPerformance').find({"sid": sid}).toArray());

}

exports.getBySidAndYear = async function (db, sid, year) {
    return (await db.collection('socialPerformance').find({"sid": sid, 'year': year}).toArray());

}
exports.create = async function(db, socialPerformance){
    db.collection('socialPerformance').insertOne(socialPerformance);
}

exports.update = async function(db, sid, year, socialPerformance ) {


    db.collection('socialPerformance').updateOne({
        "sid": sid,
        "year": year
    }, {$set: socialPerformance})
}

exports.deleteBYSid = async function(db, sid){
    db.collection('socialPerformance').deleteMany({'sid' : sid});
}

exports.deleteBySidAndYear = async function(db, sid, year){
    db.collection('socialPerformance').deleteOne({'sid' : sid, 'year': year});
}

