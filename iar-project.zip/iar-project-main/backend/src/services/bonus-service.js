const qs = require('querystring');
const axios = require('axios');
const { baseUrl, authenticate } = require('../authentication/orangeHRM');

exports.getAll = async function(db){
    return (await db.collection('bonus').find().toArray());
}

exports.getBySid = async function (db, sid) {
    return (await db.collection('bonus').find({"sid": sid}).toArray());

}

exports.getBySidAndYear = async function (db, sid, year) {
    return (await db.collection('bonus').find({"sid": sid, 'year': year}).toArray());

}
exports.create = async function(db, bonus){
    db.collection('bonus').insertOne(bonus);
}

exports.update = async function(db, sid, year, bonus ) {

    db.collection('bonus').updateOne({
        "sid": sid,
        "year": year
    }, {$set: bonus})
}

exports.deleteBySid = async function(db, sid){
    db.collection('bonus').deleteMany({'sid' : sid});
}

exports.deleteBySidAndYear = async function(db, sid, year){
    db.collection('bonus').deleteOne({'sid' : sid, 'year': year});
}

exports.confirmBonus = async function (employeeId, year, value) {
    const data = qs.stringify({
        year: year,
        value: value
    });

    await axios.post(
        `${baseUrl}/api/v1/employee/${employeeId}/bonussalary`,
        data,
        {
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                Authorization: `Bearer ${await authenticate()}`
            }
        }).catch(error => console.error(error));
}

//saves the bonus in OrangeHRM


