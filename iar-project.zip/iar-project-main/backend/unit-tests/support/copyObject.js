exports.copyObject = function (obj){
    return JSON.parse(JSON.stringify(obj));
}