export const environment = {
    production: true,
    apiEndpoint: 'http://iar-backend.inf.h-brs.de/team_17'
};
