/**
 * this model specifies the format to exchange a order with the backend
 */
import {Customer} from './Customer';
import {Position} from './Position';

export class Order {
    constructor(
        public sid: number,
        public year: number,
        public customer: Customer,
        public positions: Position[],
        public comment: string,
    ) {
    }
}
