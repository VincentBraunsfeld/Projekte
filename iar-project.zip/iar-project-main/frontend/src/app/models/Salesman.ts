/**
 * this model specifies the format to exchange a salesman with the backend
 */

export class Salesman {
    constructor(
        public sid: number,
        public employeeId: number,
        public firstName: string,
        public lastName: string,
        public department: string
    ) {
    }
}
