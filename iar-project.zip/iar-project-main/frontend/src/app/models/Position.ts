/**
 * this model specifies the format to exchange a position with the backend
 */
export class Position {
    constructor(
        public name: string,
        public quantity: string
    ) {
    }
}
