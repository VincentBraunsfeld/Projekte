/**
 * this model specifies the format to exchange a customer with the backend
 */
export class Customer {
    constructor(
        public name: string,
        public rating: string
    ) {
    }
}
