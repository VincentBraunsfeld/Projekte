import {Component, OnInit} from '@angular/core';
import {ActivatedRoute} from '@angular/router';
import {formatNumber, Location} from '@angular/common';
import {Order} from '../../models/Order';
import {Salesman} from '../../models/Salesman';
import {OrderService} from '../../services/order.service';
import {SalesmanService} from '../../services/salesman.service';

@Component({
    selector: 'app-bonus-page',
    templateUrl: './bonus-page.component.html',
    styleUrls: ['./bonus-page.component.css']
})
export class BonusPageComponent implements OnInit {
    orders: Order[] | undefined;
    salesman: Salesman;
    displayedColumns = ['product', 'client', 'ranking', 'items', 'bonus', 'comment'];
    sid = Number(this.route.snapshot.paramMap.get('sid'));
    year = Number(this.route.snapshot.paramMap.get('year'));
    totalBonusA = 0;


    constructor(
        private route: ActivatedRoute,
        private orderService: OrderService,
        private salesmanService: SalesmanService,
        private location: Location
    ) {
    }

    ngOnInit(): void {
        this.getOrder();
        this.getSalesman();
    }

    getOrder(): void {
        this.orderService.getOrdersBySidAndYear(this.sid, this.year)
            .subscribe((response): Order[] => this.orders = response.body);
    }

    getSalesman(): void {
        this.salesmanService.getSalesmanBySid(this.sid).subscribe((response): Salesman => this.salesman = response.body);
    }

    getBonusA(rating: string, items: number): number {
        let bonus = 0;
        switch (rating) {
        case 'excellent':
            bonus += 200;
            break;
        case 'very good':
            bonus += 100;
            break;
        case 'good':
            bonus += 50;
            break;
        }
        bonus += (items / 5) * 50;
        this.totalBonusA += bonus;
        return bonus;
    }

}
