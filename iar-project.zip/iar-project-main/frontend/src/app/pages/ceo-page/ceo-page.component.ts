import {Component, OnInit} from '@angular/core';
import {SalesmanService} from '../../services/salesman.service';
import {OrderService} from '../../services/order.service';
import {Salesman} from '../../models/Salesman';
import {Order} from '../../models/Order';

@Component({
    selector: 'app-ceo-page',
    templateUrl: './ceo-page.component.html',
    styleUrls: ['./ceo-page.component.css']
})
export class CeoPageComponent implements OnInit {
    orders: Order[] = [];
    salesmen: Salesman[] = [];
    selectedSalesman?: Salesman;

    constructor(private salesmanService: SalesmanService, private orderService: OrderService) {
    }

    ngOnInit(): void {
        this.fetchSalesmen();
        this.fetchOrder();
    }

    fetchSalesmen(): void {
        this.salesmanService.getSalesman().subscribe((response): void => {
            if (response.status === 200) {
                this.salesmen = response.body;
            }
        });
    }

    fetchOrder(): void {
        this.orderService.getOrders().subscribe((response): void => {
            if (response.status === 200) {
                // eslint-disable-next-line @typescript-eslint/explicit-function-return-type
                const filteredOrders = response.body.filter((order, index, self) =>
                    // eslint-disable-next-line @typescript-eslint/explicit-function-return-type
                    self.findIndex(o => o.sid === order.sid && o.year === order.year) === index);

                this.orders = filteredOrders;
            }
        });
    }

    onSelect(selectedSalesman: Salesman): void {
        this.selectedSalesman = selectedSalesman;
    }

    getOrdersBySid(sid: number): Order[] {
        console.log(this.orders.filter((order: Order): boolean => order.sid === sid));
        return this.orders.filter((order: Order): boolean => order.sid === sid);
    }

}
