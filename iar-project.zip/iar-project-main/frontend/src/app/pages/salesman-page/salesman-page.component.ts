import {Component, OnInit} from '@angular/core';
import {MatTableDataSource} from '@angular/material/table';
import {SalesmanService} from '../../services/salesman.service';
import {Salesman} from '../../models/Salesman';
import {Order} from '../../models/Order';
import {OrderService} from '../../services/order.service';

@Component({
    selector: 'app-salesman-page',
    templateUrl: './salesman-page.component.html',
    styleUrls: ['./salesman-page.component.css']
})
export class SalesmanPageComponent implements OnInit {

    dataSource1: MatTableDataSource<Salesman>;
    dataSource2: MatTableDataSource<Order>;
    orders: Order[] = [];
    displayedColumns1: string[] = ['id', 'firstname', 'lastname', 'department'];
    displayedColumns2: string[] = ['id', 'year'];
    filterValue: string;
    selectedSalesman?: Salesman;


    constructor(private salesmanService: SalesmanService, private orderService: OrderService) {
    }

    ngOnInit(): void {
        this.fetchSalesmen();
        this.fetchOrder();
    }

    fetchSalesmen(): void {
        this.salesmanService.getSalesman().subscribe((response): void => {
            if (response.status === 200) {
                this.dataSource1 = new MatTableDataSource<Salesman>(response.body);
            }
        });
    }

    fetchOrder(): void {
        this.orderService.getOrders().subscribe((response): void => {
            if (response.status === 200) {
                // eslint-disable-next-line @typescript-eslint/explicit-function-return-type
                const filteredOrders = response.body.filter((order, index, self) =>
                    // eslint-disable-next-line @typescript-eslint/explicit-function-return-type
                    self.findIndex(o => o.sid === order.sid && o.year === order.year) === index
                );

                this.orders = filteredOrders;
            }
        });
    }

    getOrdersBySid(sid: number): void {
        this.dataSource2 = new MatTableDataSource<Order>(this.orders.filter((order: Order): boolean => order.sid === sid));
    }

    applyFilter(): void {
        this.dataSource1.filter = this.filterValue.trim().toLowerCase();
    }

    onSalesmanClick(selectedSalesman: Salesman): void {
        this.selectedSalesman = selectedSalesman;
        this.getOrdersBySid(selectedSalesman.sid);
    }
}
