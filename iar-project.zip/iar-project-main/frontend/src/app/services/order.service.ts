import { Injectable } from '@angular/core';
import {HttpClient, HttpResponse} from '@angular/common/http';
import {Observable} from 'rxjs';
import {Order} from '../models/Order';
import {environment} from '../../../environments/environment';

@Injectable({
    providedIn: 'root'
})
export class OrderService {

    constructor(private http: HttpClient) {
    }
    getOrders(): Observable<HttpResponse<Order[]>>{
        return this.http.get<Order[]>
        (environment.apiEndpoint + '/api/order', {observe: 'response', withCredentials: true});
    }

    getOrdersBySid(sid: number): Observable<HttpResponse<Order[]>>{
        return this.http.get<Order[]>
        (environment.apiEndpoint + `/api/order/${sid}`, {observe: 'response', withCredentials: true});
    }

    getOrdersBySidAndYear(sid: number, year: number): Observable<HttpResponse<Order[]>>{
        return this.http.get<Order[]>
        (environment.apiEndpoint + `/api/order/${sid}/${year}`, {observe: 'response', withCredentials: true});
    }
}
