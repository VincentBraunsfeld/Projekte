export interface ExampleDatapoint{
    id: string;
    name: string;
    favourite_color: {
        name: string;
        code: string;
    };
    age: number;
}
